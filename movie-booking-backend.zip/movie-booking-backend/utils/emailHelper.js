exports.sendConfirmationEmail = async (email, bookingDetails) => {
    // Dummy email sending function
    console.log(`Sending confirmation email to ${email}`, bookingDetails);
  };
  