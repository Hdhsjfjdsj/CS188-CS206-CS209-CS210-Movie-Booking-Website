const express = require('express');  // Import express
const cors = require('cors');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const movieRoutes = require('./routes/movieRoutes');
const bookingRoutes = require('./routes/bookingRoutes');
const errorHandler = require('./middleware/errorHandler');
const profileRoutes = require('./routes/profileRoutes');

// Initialize the express app
const app = express();

dotenv.config();

// Set up CORS middleware
app.use(cors({
  origin: 'http://localhost:3000',  // Allow frontend origin
  credentials: true,  // Allow credentials (cookies, etc)
}));

const PORT = process.env.PORT || 5000;

// Connect to MongoDB
connectDB();

// Middleware
app.use(express.json());  // Parse JSON bodies

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/movies', movieRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/profile', profileRoutes);
// Root Route
app.get('/', (req, res) => {
  res.send('Movie Booking Backend is running!');
});

// Error-Handling Middleware
app.use(errorHandler);

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
