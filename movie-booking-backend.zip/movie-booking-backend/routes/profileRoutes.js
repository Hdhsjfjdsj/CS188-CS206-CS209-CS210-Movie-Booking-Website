const express = require('express');
const { getProfile, updateProfile } = require('../controllers/profileController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// Protected routes
router.get('/', authMiddleware, getProfile); // Fetch user profile
router.put('/', authMiddleware, updateProfile); // Update user profile

module.exports = router;
