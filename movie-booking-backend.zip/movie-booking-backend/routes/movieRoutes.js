const express = require('express');
const { getMovies, getMovieById, addMovie } = require('../controllers/movieController');
const router = express.Router();

// Movie-related routes
router.get('/', getMovies);            // Get all movies
router.get('/:id', getMovieById);      // Get a single movie by its ID
router.post('/add', addMovie);         // Add a new movie (POST request)

// Export the routes
module.exports = router;

