const express = require('express');
const { register, login } = require('../controllers/authController');
const { getProfile } = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware'); // Middleware to authenticate user


const router = express.Router();

router.post('/register', register);
router.post('/login', login);
router.get('/profile', authMiddleware, (req, res) => {
    console.log('Profile route accessed'); // This should show up in the server logs when the request is made
    getProfile(req, res);
  });

module.exports = router;
