const Movie = require('../models/Movie');

// Get all movies
exports.getMovies = async (req, res) => {
  try {
    const movies = await Movie.find();
    res.status(200).json(movies);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching movies', error: error.message });
  }
};

// Get movie by ID
exports.getMovieById = async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.id);
    if (!movie) return res.status(404).json({ message: 'Movie not found' });
    res.status(200).json(movie);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching movie', error: error.message });
  }
};

// Add a new movie
exports.addMovie = async (req, res) => {
  try {
    const { title, genre, duration, releaseDate } = req.body;

    // Validate the required fields
    if (!title || !genre || !duration || !releaseDate) {
      return res.status(400).json({ message: 'All fields are required.' });
    }

    // Create a new movie document and save to the database
    const newMovie = new Movie({ title, genre, duration, releaseDate });
    await newMovie.save();

    res.status(201).json({ message: 'Movie added successfully', movie: newMovie });
  } catch (error) {
    res.status(500).json({ message: 'Failed to add movie', error: error.message });
  }
};
