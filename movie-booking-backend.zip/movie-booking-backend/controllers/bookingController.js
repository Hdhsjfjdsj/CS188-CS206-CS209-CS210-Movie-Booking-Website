const Booking = require('../models/Booking');

// Create a booking
exports.createBooking = async (req, res) => {
  try {
    const { userId } = req.user; // userId from JWT
    const { movieId, seats, snacks } = req.body;

    if (!movieId || !seats) {
      return res.status(400).json({ message: 'Movie and seats are required.' });
    }

    const newBooking = await Booking.create({ userId, movieId, seats, snacks });
    res.status(201).json({ message: 'Booking successful', booking: newBooking });
  } catch (error) {
    res.status(500).json({ message: 'Error creating booking', error: error.message });
  }
};

// Get all bookings for the logged-in user
exports.getBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ userId: req.user.userId });
    res.status(200).json(bookings);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching bookings', error: error.message });
  }
};
