import React, { useEffect } from 'react';
import QRious from 'qrious';
import './ticket.css'; // Make sure you have your CSS for the ticket styles
import downloadImage from './download.jpeg';

const Ticket = () => {
  useEffect(() => {
    // QR Code generation logic (non-dynamic for now)
    const qr = new QRious({
      element: document.getElementById('qr-code'),
      value: 'https://example.com/ticket', // Static URL or booking ID
      size: 100,
    });

    // Set a static booking ID
    document.getElementById('booking-id').textContent = 'ABC12345XYZ';
  }, []);

  return (
    <div className="ticket-container">
      <h1>YOUR TICKET :</h1>
      <div className="ticket-details">
        <img src={downloadImage} alt="Movie Poster" className="ticket-poster" />
        <div className="ticket-info">
          <h2>DEVARA (UA)</h2>
          <p>TELUGU 2D</p>
          <p>THU, 24 OCT | 7:00 PM</p>
          <p>INOX GALLERIA</p>
        </div>
        <p className="ticket-quantity">3 TICKETS</p>
        <p className="ticket-screen">SCREEN 03</p>
        <p className="ticket-seats">E4, E5, E6</p>
        <canvas id="qr-code"></canvas>
        <p className="booking-id">
          BOOKING ID: <span id="booking-id"></span>
        </p>
      </div>
    </div>
  );
};

export default Ticket;
