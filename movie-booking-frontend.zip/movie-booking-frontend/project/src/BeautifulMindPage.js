import React from "react";
import { useNavigate } from "react-router-dom";

function BeautifulMind() {
    const navigate = useNavigate(); // Hook to navigate

    // Function to navigate to the booking page
    const handleBookTicketsClick = () => {
        navigate("/booking"); // This will navigate to the booking route
    };

    const styles = {
        body: {
            fontFamily:
                "'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif",
            backgroundColor: "#fff",
            margin: 0,
            padding: 0,
            color: "#333",
            textAlign: "center",
        },
        container: {
            maxWidth: "1080px",
            margin: "auto",
            padding: "20px",
        },
        title: {
            fontSize: "4rem",
            fontWeight: "bold",
        },
        movieInfo: {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-around",
            marginTop: "20px",
        },
        movieImageWrapper: {
            position: "relative",
            maxWidth: "50%",
        },
        movieImage: {
            width: "100%",
            borderRadius: "8px",
        },
        trailerButton: {
            position: "absolute",
            top: "20px",
            left: "20px",
            background: "rgba(255, 0, 0, 0.8)",
            color: "white",
            fontWeight: "bold",
            padding: "10px",
            borderRadius: "5px",
            cursor: "pointer",
        },
        description: {
            maxWidth: "45%",
            textAlign: "left",
        },
        descriptionText: {
            fontSize: "1.3rem",
            fontWeight: "normal",
            marginTop: 0,
        },
        stats: {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-around",
            marginTop: "10px",
        },
        rating: {
            fontSize: "1.5rem",
            color: "#000",
        },
        options: {
            display: "flex",
            justifyContent: "center",
            gap: "20px",
            marginTop: "20px",
        },
        option: {
            backgroundColor: "#000",
            color: "#fff",
            padding: "10px 10px",
            borderRadius: "6px",
        },
        ticketsInfo: {
            fontSize: "1.4rem",
            color: "green",
            marginTop: "10px",
        },
        bookButton: {
            backgroundColor: "red",
            color: "white",
            width: "100%",
            display: "block",
            textDecoration: "none",
            textAlign: "center",
            padding: "10px 20px",
            fontSize: "1rem",
            fontWeight: "bold",
            textTransform: "uppercase",
            borderRadius: "5px",
            marginTop: "20px",
        },
    };

    return (
        <div style={styles.body}>
            <div style={styles.container}>
                {/* Title */}
                <div style={styles.title}>A BEAUTIFUL MIND</div>

                {/* Movie Info Section */}
                <div style={styles.movieInfo}>
                    {/* Movie Image */}
                    <div style={styles.movieImageWrapper}>
                        <a href="https://www.example.com/book-tickets">
                            <img
                                src="https://wallpapercave.com/wp/wp6720422.jpg"
                                alt="A Beautiful Mind Movie Poster"
                                style={styles.movieImage}
                            />
                        </a>
                        <div style={styles.trailerButton}>&gt; TRAILER (4)</div>
                    </div>

                    {/* Description */}
                    <div style={styles.description}>
                        <p style={styles.descriptionText}>
                            A Beautiful Mind is a 2001 American biographical drama film about
                            the mathematician John Nash, a Nobel Laureate in Economics, played
                            by Russell Crowe. The film is directed by Ron Howard based on a
                            screenplay by Akiva Goldsman, who adapted the 1998 biography by
                            Sylvia Nasar...more
                        </p>
                        <div style={styles.stats}>
                            <div style={styles.rating}>⭐ 8.2/10 (320.2K Views)</div>
                            <div style={styles.options}>
                                <div style={styles.option}>2D IMAX 2D, 4DX, ICE</div>
                                <div style={styles.option}>ENGLISH, HINDI, +3</div>
                            </div>
                        </div>
                        <div style={styles.ticketsInfo}>
                            10.11K Tickets booked in last 24 hours
                        </div>
                    </div>
                </div>

                {/* Book Button */}
                <a  style={styles.bookButton} onClick={handleBookTicketsClick}>
                    Book Tickets
                </a>
            </div>
        </div>
    );
}

export default BeautifulMind;