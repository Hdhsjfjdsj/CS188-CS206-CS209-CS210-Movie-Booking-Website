import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function LoginPage() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [errorMessage, setErrorMessage] = useState("");
    const [isLoggedIn, setIsLoggedIn] = useState(false); // State for login status
    const navigate = useNavigate(); // Hook for navigation

    const handleLogin = async () => {
        if (!email || !password) {
            setErrorMessage("Please fill in all fields.");
            return;
        }
    
        try {
            const response = await axios.post(
                "http://localhost:5000/api/auth/login",
                { email, password },
                { headers: { "Content-Type": "application/json" } }
            );
    
            console.log("Login Response:", response.data);  // Debug log
    
            if (response.data.token) {
                localStorage.setItem("token", response.data.token);
                localStorage.setItem("isLoggedIn", "true");
                setIsLoggedIn(true); // This should trigger the useEffect
                console.log("Logged in successfully!"); // Debug log
            } else {
                setErrorMessage(response.data.message);
            }
        } catch (error) {
            setErrorMessage("An error occurred. Please try again later.");
            console.error("Login error:", error);
        }
    };
    
    // Navigate to ProfilePage when logged in
    useEffect(() => {
        console.log("isLoggedIn:", isLoggedIn); // Debug log
        if (isLoggedIn) {
            console.log("Navigating to ProfilePage...");
            navigate("/profile");
        }
    }, [isLoggedIn, navigate]);
    
    

    // Navigate to Register Page
    const goToRegister = () => {
        navigate("/register"); // Redirect to register page
    };

    return (
        <div style={styles.body}>
            <header style={styles.header}>
                <h1>LOGIN</h1>
            </header>

            <div style={styles.container}>
                <h2>Login to your account</h2>
                {errorMessage && <p style={styles.errorMessage}>{errorMessage}</p>}
                <div style={styles.form}>
                    <input
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        style={styles.input}
                    />
                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        style={styles.input}
                    />
                    <button onClick={handleLogin} style={styles.button}>
                        Login
                    </button>
                </div>

                {/* Link to Register New User */}
                <div style={styles.registerLinkContainer}>
                    <p style={styles.registerText}>
                        Don't have an account?{" "}
                        <span onClick={goToRegister} style={styles.registerLink}>
                            Register here
                        </span>
                    </p>
                </div>
            </div>
        </div>
    );
}

const styles = {
    body: {
        fontFamily: "Arial, sans-serif",
        margin: 0,
        padding: 0,
        backgroundColor: "#f5f5f5",
    },
    header: {
        backgroundColor: "#e63946",
        color: "white",
        textAlign: "center",
        padding: "20px",
        fontSize: "1.5rem",
        fontWeight: "bold",
    },
    container: {
        maxWidth: "400px",
        margin: "20px auto",
        padding: "20px",
        backgroundColor: "#fff",
        borderRadius: "10px",
        boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
    },
    form: {
        display: "flex",
        flexDirection: "column",
        gap: "15px",
    },
    input: {
        padding: "10px",
        fontSize: "1rem",
        borderRadius: "5px",
        border: "1px solid #ddd",
    },
    button: {
        backgroundColor: "#e63946",
        color: "white",
        padding: "10px 20px",
        border: "none",
        borderRadius: "5px",
        fontSize: "1rem",
        fontWeight: "bold",
        cursor: "pointer",
    },
    errorMessage: {
        color: "red",
        fontSize: "0.9rem",
        marginBottom: "10px",
    },
    registerLinkContainer: {
        marginTop: "10px",
        textAlign: "center",
    },
    registerText: {
        fontSize: "1rem",
    },
    registerLink: {
        color: "#e63946",
        fontWeight: "bold",
        cursor: "pointer",
    },
};

export default LoginPage;
