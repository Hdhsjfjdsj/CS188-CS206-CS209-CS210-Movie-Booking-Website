import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import MainPage from "./MainPage"; // Replace with the actual file name for the first file
import DevaraPage from "./DevaraPage"; // Replace with the actual file name for the second file

function App() {
    const styles = {
        nav: {
            backgroundColor: "#e63946",
            padding: "10px",
            display: "flex",
            justifyContent: "center",
        },
        navLink: {
            color: "white",
            textDecoration: "none",
            fontWeight: "bold",
            fontSize: "1.2rem",
            margin: "0 20px",
            cursor: "pointer",
        },
    };

    return (
        <Router>
            <div>
                {/* Navigation Bar */}
                <nav style={styles.nav}>
                    <Link to="/" style={styles.navLink}>
                        Home
                    </Link>
                    <Link to="/devara" style={styles.navLink}>
                        Devara
                    </Link>
                </nav>

                {/* Define Routes */}
                <Routes>
                    <Route path="/" element={<MainPage />} />
                    <Route path="/devara" element={<DevaraPage />} />
                </Routes>
            </div>
        </Router>
    );
}

export default App;
