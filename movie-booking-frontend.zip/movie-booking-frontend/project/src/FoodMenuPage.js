import React from "react";
import { useNavigate } from "react-router-dom";

const FoodMenu = () => {
  const menuItems = [
    { id: 1, img: "popcorn.png", name: "Popcorn", size: "Medium Size", price: 110 },
    { id: 2, img: "coca cola.png", name: "Coca-Cola", size: "Medium Size", price: 115 },
    { id: 3, img: "pepsi.png", name: "Pepsi", size: "Medium", price: 120 },
    { id: 4, img: "chocolate.png", name: "Dairy Milk - Silk", size: "Large", price: 80 },
    { id: 5, img: "nachos.png", name: "Nachos", size: "Large", price: 280 },
    { id: 6, img: "popcorn.png", name: "Popcorn", size: "Large", price: 210 },
  ];

  const navigate = useNavigate();

  const handleAddToCart = (itemName) => {
    alert(`${itemName} added to cart!`);
  };

  const proceedToCheckout = () => {
    navigate("/booking-confirmation"); // Navigates to the route for BookingConfirmationPage
  };

  return (
    <>
      <style>{`
        body {
          display: flex;
          justify-content: center;
          align-items: center;
          min-height: 80vh;
          background-color: #f2f2f2;
        }
        .container {
          display: flex;
          justify-content: center;
          align-items: flex-start;
          flex-wrap: wrap;
          gap: 10px;
          padding: 20px;
          background-color: #fff;
          border-radius: 10px;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }
        h1 {
          text-align: center;
          margin-bottom: 50px;
          color: #e10d57;
        }
        .item {
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          width: 200px;
          padding: 15px;
          background-color: #f2f2f2;
          border-radius: 10px;
        }
        .item h3 {
          margin-bottom: 10px;
        }
        .item img {
          width: 100px;
          height: 100px;
          object-fit: cover;
          border-radius: 50%;
          margin-bottom: 10px;
        }
        .item p {
          margin-bottom: 10px;
          font-size: 14px;
        }
        .item .price {
          font-size: 20px;
          font-weight: bold;
        }
        .item button {
          padding: 10px 20px;
          background-color: #ff5733;
          color: #fff;
          border: none;
          border-radius: 5px;
          cursor: pointer;
          transition: background-color 0.3s;
        }
        .item button:hover {
          background-color: #11e883;
        }
        .skip-button {
          background-color: #f44336;
          color: white;
          padding: 10px 20px;
          border: none;
          border-radius: 5px;
          cursor: pointer;
          float: right;
          margin-top: 20px;
        }
        .skip-button:hover {
          background-color: #b3e535;
        }
      `}</style>

      <h1>Food Menu</h1>
      <div className="container">
        {menuItems.map((item) => (
          <div className="item" key={item.id}>
            <img src={item.img} alt={item.name} />
            <h3>{item.name}</h3>
            <p>{item.size}</p>
            <div className="price">Rs {item.price}</div>
            <button onClick={() => handleAddToCart(item.name)}>Add</button>
          </div>
        ))}
      </div>
      <div>
        <button className="skip-button" onClick={proceedToCheckout}>
          Proceed to checkout
        </button>
      </div>
    </>
  );
};

export default FoodMenu;
