import React from "react";
import { useNavigate } from "react-router-dom";
import "./booking_confirmation.css";

const OrderConfirmation = () => {
  const navigate = useNavigate();

  const handleConfirmClick = () => {
    navigate("/deals"); // Adjust the route to match your app's routing setup
  };

  return (
    <div className="order-container">
      <h2>Current order :</h2>
      <div className="order-content">
        <div className="movie-info">
          <img src="download.jpeg" alt="Movie Poster" />
          <div className="movie-details">
            <p>INOX GALLERIA | TELUGU | 2D</p>
            <p>E4, E5, E6</p>
          </div>
        </div>
        <div className="ticket-details">
          <h3>INOX GALLERIA MALL</h3>
          <p>SEATS : E4, E5, E6</p>
          <div className="cost-details">
            <p>
              <span>TICKET COST :</span>
            </p>
            <ul>
              <li>
                1. ADULT <span>200rs</span>
              </li>
              <li>
                2. ADULT <span>200rs</span>
              </li>
              <li>
                3. ADULT <span>200rs</span>
              </li>
            </ul>
            <p className="subtotal">
              <span>SUBTOTAL</span> <span>600rs</span>
            </p>
          </div>
        </div>
      </div>
      <button className="confirm-btn" onClick={handleConfirmClick}>
        CONFIRM TICKETS
      </button>
    </div>
  );
};

export default OrderConfirmation;
