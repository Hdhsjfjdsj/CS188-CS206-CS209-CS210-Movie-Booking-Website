import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Booking = () => {
  const [selectedMovieTitle, setSelectedMovieTitle] = useState(null);
  const navigate=useNavigate();

  useEffect(() => {
    const movieTitle = localStorage.getItem("selectedMovieTitle");
    setSelectedMovieTitle(movieTitle);

    // Show popup on load
    document.getElementById("popup").style.display = "flex";
  }, []);

  const closePopup = () => {
    document.getElementById("popup").style.display = "none";
  };

  const showTheaterScreen = (language, format) => {
    document.getElementById("popup").style.display = "none";
    document.getElementById("theaterScreen").style.display = "block";
    document.getElementById("languageFormat").innerText = `${language} - ${format}`;
  };

  const showSeatSelection = () => {
    document.getElementById("theaterScreen").style.display = "none";
    document.getElementById("seatSelection").style.display = "flex";
    loadSeats();
  };

  const loadSeats = () => {
    const seatContainer = document.getElementById("seatContainer");
    seatContainer.innerHTML = "";
    for (let row = 1; row <= 5; row++) {
      const seatRow = document.createElement("div");
      seatRow.className = "seat-row";
      for (let col = 1; col <= 8; col++) {
        const seat = document.createElement("div");
        seat.className = "seat available";
        seat.innerText = `${row}${String.fromCharCode(64 + col)}`;
        seat.addEventListener("click", () => toggleSeatSelection(seat));
        seatRow.appendChild(seat);
      }
      seatContainer.appendChild(seatRow);
    }
  };

  const toggleSeatSelection = (seat) => {
    if (seat.classList.contains("available")) {
      seat.classList.toggle("selected");
    }
  };

  const proceedToFoodSelection = () => {
    navigate("/food-menu"); // Navigate to FoodMenuPage.js
  };

  return (
    <div>
      {/* Popup Modal */}
      <div id="popup" className="popup">
        <div className="popup-content">
          <button
            id="closeButton"
            className="close-button"
            onClick={closePopup}
          >
            &times;
          </button>
          <p id="movieName">{selectedMovieTitle || "Unknown Movie"}</p>
          <h2>Select language and format</h2>
          <div className="options">
            <div>
              <h3>Telugu</h3>
              <button onClick={() => showTheaterScreen("Telugu", "2D")}>
                2D
              </button>
              <button onClick={() => showTheaterScreen("Telugu", "3D")}>
                3D
              </button>
              <button onClick={() => showTheaterScreen("Telugu", "IMAX")}>
                IMAX
              </button>
            </div>
            <div>
              <h3>Kannada</h3>
              <button onClick={() => showTheaterScreen("Kannada", "2D")}>
                2D
              </button>
              <button onClick={() => showTheaterScreen("Kannada", "3D")}>
                3D
              </button>
              <button onClick={() => showTheaterScreen("Kannada", "IMAX")}>
                IMAX
              </button>
            </div>
            <div>
              <h3>Hindi</h3>
              <button onClick={() => showTheaterScreen("Hindi", "2D")}>
                2D
              </button>
              <button onClick={() => showTheaterScreen("Hindi", "3D")}>
                3D
              </button>
              <button onClick={() => showTheaterScreen("Hindi", "IMAX")}>
                IMAX
              </button>
            </div>
            <div>
              <h3>Tamil</h3>
              <button onClick={() => showTheaterScreen("Tamil", "2D")}>
                2D
              </button>
              <button onClick={() => showTheaterScreen("Tamil", "3D")}>
                3D
              </button>
              <button onClick={() => showTheaterScreen("Tamil", "IMAX")}>
                IMAX
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Theater and Timing Screen */}
      <div id="theaterScreen" className="theater-timing">
        <div className="theater-header">
          <span id="movieTitle">
            Devara - <span id="languageFormat"></span>
          </span>
          <div>
            <select>
              <option>Filter Price Range</option>
            </select>
            <select>
              <option>Filter Show Timings</option>
            </select>
          </div>
        </div>
        <div className="theater">
          <h3>Cinepolis: Lulu Mall</h3>
          <div className="showtimes">
            <button className="showtime-button" onClick={showSeatSelection}>
              10:00 AM
            </button>
            <button className="showtime-button" onClick={showSeatSelection}>
              1:00 PM
            </button>
            <button className="showtime-button" onClick={showSeatSelection}>
              4:00 PM
            </button>
            <button className="showtime-button" onClick={showSeatSelection}>
              7:00 PM
            </button>
            <button className="showtime-button" onClick={showSeatSelection}>
              10:00 PM
            </button>
          </div>
        </div>
        <div className="theater">
          <h3>Gopalan Cinemas: Arcade Mall</h3>
          <div className="showtimes">
            <button className="showtime-button" onClick={showSeatSelection}>
              10:15 AM
            </button>
            <button className="showtime-button" onClick={showSeatSelection}>
              1:15 PM
            </button>
            <button className="showtime-button" onClick={showSeatSelection}>
              4:15 PM
            </button>
            <button className="showtime-button" onClick={showSeatSelection}>
              7:15 PM
            </button>
            <button className="showtime-button" onClick={showSeatSelection}>
              10:15 PM
            </button>
          </div>
        </div>
        <div className="theater">
          <h3>INOX: Galleria Mall</h3>
          <div className="showtimes">
            <button className="showtime-button" onClick={showSeatSelection}>
              10:30 AM
            </button>
            <button className="showtime-button" onClick={showSeatSelection}>
              1:30 PM
            </button>
            <button className="showtime-button" onClick={showSeatSelection}>
              4:30 PM
            </button>
            <button className="showtime-button" onClick={showSeatSelection}>
              7:30 PM
            </button>
            <button className="showtime-button" onClick={showSeatSelection}>
              10:30 PM
            </button>
          </div>
        </div>
      </div>

      {/* Seat Selection Screen */}
      <div id="seatSelection" className="seat-section">
  <div className="seat-wrapper">
    <div className="screen">SCREEN</div>
    <div id="seatContainer" className="seat-container"></div>
    <div className="legend">
      <div>
        <div className="box available-box"></div> Available
      </div>
      <div>
        <div className="box selected-box"></div> Selected
      </div>
      <div>
        <div className="box sold-out-box"></div> Sold Out
      </div>
    </div>
  </div>
  <button className="next-button" onClick={proceedToFoodSelection}>
   Next
  </button>
</div>

      <style>{`
        body {
  font-family: 'Roboto', sans-serif;
  margin: 0;
  padding: 0;
  background-color: #f7f7f7;
}

h1, h2, h3 {
  color: #333;
  font-weight: 600;
}

/* Popup Modal */
.popup {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.7);
  justify-content: center;
  align-items: center;
  padding: 20px;
}

.popup-content {
  background: #fff;
  padding: 30px;
  border-radius: 8px;
  text-align: center;
  position: relative;
  width: 90%;
  max-width: 700px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.close-button {
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 24px;
  cursor: pointer;
  background: none;
  border: none;
}

h2 {
  font-size: 24px;
  margin-top: 20px;
  font-weight: 500;
  color: #333;
}

.options {
  display: flex;
  justify-content: space-around;
  margin-top: 20px;
  flex-wrap: wrap;
}

.options div {
  width: 120px;
}

button {
  background-color: #f44336;
  color: white;
  padding: 10px 20px;
  margin: 5px;
  border: none;
  border-radius: 3px;
  cursor: pointer;
  font-size: 16px;
}

button:hover {
  background-color: #d32f2f;
}

/* Theater & Timing Screen */
.theater-timing {
  display: none;
  margin: 20px;
  padding: 20px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.theater-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

#movieTitle {
  font-size: 24px;
  font-weight: 600;
  color: #333;
}

select {
  padding: 8px;
  font-size: 16px;
  border-radius: 4px;
  border: 1px solid #ccc;
}

.selects-container {
  display: flex;
  gap: 15px;
  align-items: center;
}

.selects-container select {
  width: 180px;
}

/* Showtimes */
.showtimes {
  display: flex;
  gap: 10px;
  margin-top: 10px;
}

.showtime-button {
  background-color: #007bff;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 3px;
  cursor: pointer;
  font-size: 16px;
  width: 100px;
}

.showtime-button:hover {
  background-color: #0056b3;
}

/* Seat Selection Screen */
.seat-section {
  display: none;
  flex-direction: column;
  justify-content: space-between;
  height: 100vh;
  padding: 0 20px;
  box-sizing: border-box;
  text-align: center;
}

.screen {
  margin: 20px 0;
  font-size: 24px;
  font-weight: 600;
  color: #333;
  background-color: #ccc;
  padding: 10px;
  border-radius: 4px;
}

.seat-row {
  display: flex;
  justify-content: center;
  margin: 5px;
}

.seat {
  width: 40px;
  height: 40px;
  margin: 5px;
  background-color: #ccc;
  border: 1px solid #ccc;
  text-align: center;
  line-height: 40px;
  cursor: pointer;
  font-size: 16px;
  border-radius: 5px;
}

.seat.available {
  background-color: #4caf50;
}

.seat.available:hover {
  background-color: #45a049;
}

.seat.selected {
  background-color: #ffeb3b;
}

.seat.selected:hover {
  background-color: #fbc02d;
}

.legend {
  display: flex;
  justify-content: space-around;
  margin-top: 20px;
}

.legend div {
  display: flex;
  align-items: center;
}

.box {
  width: 20px;
  height: 20px;
  border-radius: 3px;
  margin-right: 5px;
}

.available-box {
  background-color: #4caf50;
}

.selected-box {
  background-color: #ffeb3b;
}

.sold-out-box {
  background-color: #bbb;
}

/* Next Button */
.next-button {
  position: fixed;
  bottom: 10px;
  left: 50%;
  transform: translateX(-50%);
  background-color: #2196f3;
  color: white;
  padding: 12px 30px;
  border: none;
  border-radius: 20px;
  cursor: pointer;
  font-size: 16px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  transition: all 0.3s ease;
}

.next-button:hover {
  background-color: #1976d2;
  transform: translateX(-50%) scale(1.05);
}

.next-button:active {
  background-color: #1565c0;
  transform: translateX(-50%) scale(0.95);
}

/* Mobile Responsiveness */
@media (max-width: 768px) {
  .options {
    flex-direction: column;
    align-items: center;
  }

  .options div {
    width: 100%;
    margin-bottom: 15px;
  }

  .showtimes {
    flex-direction: column;
  }

  .showtime-button {
    width: 80%;
    margin-bottom: 10px;
  }

  .seat-row {
    flex-direction: column;
  }

  .seat {
    margin-bottom: 10px;
  }

  .legend {
    flex-direction: column;
  }

  .next-button {
    width: calc(100% - 20px);
  }
}

          
      `}</style>
    </div>
  );
};

export default Booking;
