import React from "react";
import { useNavigate } from "react-router-dom";

function Aavesham() {
    const navigate = useNavigate(); // Hook to navigate

    // Function to navigate to the booking page
    const handleBookTicketsClick = () => {
        navigate("/booking"); // This will navigate to the booking route
    };

    const styles = {
        body: {
            fontFamily: "'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif",
            backgroundColor: "#fff",
            margin: 0,
            padding: 0,
            color: "#333",
        },
        container: {
            maxWidth: "1080px",
            margin: "auto",
            padding: "20px",
            textAlign: "center",
        },
        title: {
            fontSize: "4rem",
            fontWeight: "bold",
        },
        movieInfo: {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-around",
            marginTop: "20px",
        },
        movieImage: {
            position: "relative",
            maxWidth: "50%",
        },
        movieImageImg: {
            width: "100%",
            borderRadius: "8px",
        },
        trailerButton: {
            position: "absolute",
            top: "20px",
            left: "20px",
            background: "rgba(255, 0, 0, 0.8)",
            color: "white",
            fontWeight: "bold",
            padding: "10px",
            borderRadius: "5px",
            cursor: "pointer",
        },
        description: {
            maxWidth: "45%",
            textAlign: "left",
        },
        descriptionText: {
            marginTop: 2,
            fontSize: "1.2rem",
            fontWeight: "normal",
        },
        stats: {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-around",
            marginTop: "10px",
        },
        statsSpan: {
            fontWeight: "bold",
            color: "#888",
        },
        rating: {
            fontSize: "1.5rem",
            color: "#000",
        },
        buttons: {
            marginTop: "20px",
        },
        btn: {
            padding: "10px 20px",
            fontSize: "1rem",
            fontWeight: "bold",
            textTransform: "uppercase",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
        },
        bookBtn: {
            backgroundColor: "red",
            color: "white",
            width: "100%",
            display: "block",
            textDecoration: "none",
            textAlign: "center",
        },
        options: {
            display: "flex",
            justifyContent: "center",
            gap: "20px",
            marginTop: "20px",
        },
        option: {
            backgroundColor: "#000",
            color: "#fff",
            padding: "10px 10px",
            borderRadius: "6px",
        },
        ticketsInfo: {
            fontSize: "1.5rem",
            color: "green",
            marginTop: "10px",
        },
    };

    return (
        <div style={styles.body}>
            <div style={styles.container}>
                <div style={styles.title}>Aavesham</div>

                <div style={styles.movieInfo}>
                    <div style={styles.movieImage}>
                        <a href="https://www.example.com/book-tickets">
                            <img
                                src="https://m.media-amazon.com/images/M/MV5BNjJjY2IxMDYtN2U0My00MzFiLWJlYzItYmJkMDg1MTg3MjhmXkEyXkFqcGc@.V1_FMjpg_UX1000.jpg"
                                alt="Aavesham Movie Poster"
                                style={styles.movieImageImg}
                            />
                        </a>
                        <div style={styles.trailerButton}> &gt; TRAILER (4)</div>
                    </div>

                    <div style={styles.description}>
                        <h3 style={styles.descriptionText}>
                            Three teenagers reach Bangalore for their engineering degree and get involved in a fight with seniors. They find a local gangster named Ranga to help them take revenge.
                        </h3>
                        <div style={styles.stats}>
                            <div style={styles.rating}>⭐ 8.7/10 (372.2K Views)</div>
                            <div style={styles.options}>
                                <div style={styles.option}>2D IMAX 2D, 4DX, ICE</div>
                                <div style={styles.option}>KANNADA, TELUGU, +3</div>
                            </div>
                        </div>
                        <div style={styles.ticketsInfo}>10.11K Tickets booked in last 24 hours</div>
                    </div>
                </div>

                <div style={styles.buttons}>
                    <button
                        onClick={handleBookTicketsClick}
                        style={{ ...styles.btn, ...styles.bookBtn }}
                    >
                        Book Tickets
                    </button>
                </div>
            </div>
        </div>
    );
}

export default Aavesham;
