import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function ProfilePage() {
    const navigate = useNavigate();
    const [isEditing, setIsEditing] = useState(false);
    const [isManagingPayment, setIsManagingPayment] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");
    const [upiId, setUpiId] = useState("");
    const [creditCard, setCreditCard] = useState("");

    // Fetch user data when the component mounts
    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const token = localStorage.getItem("token");
                const response = await axios.get("http://localhost:5000/api/auth/profile", {
                    headers: { "Authorization": `Bearer ${token}` }
                });

                const { name, email, phone, upiId, creditCard } = response.data;
                setName(name);
                setEmail(email);
                setPhone(phone);
                setUpiId(upiId || ""); // Set initial values for payment methods
                setCreditCard(creditCard || ""); // Set initial values for payment methods
            } catch (error) {
                console.error("Error fetching profile:", error);
            }
        };

        fetchProfile();
    }, []);

    // Handle profile submit
    const handleProfileSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        try {
            const token = localStorage.getItem("token");
            await axios.post(
                "http://localhost:5000/api/profile",
                { name, email, phone },
                { headers: { "Authorization": `Bearer ${token}` } }
            );
            alert("Profile updated!");
        } catch (error) {
            console.error("Error updating profile:", error);
            alert("Failed to update profile. Please try again.");
        } finally {
            setIsSubmitting(false);
        }
    };

    // Handle payment methods submit
    const handlePaymentSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        try {
            const token = localStorage.getItem("token");
            await axios.post(
                "http://localhost:5000/api/payment-methods",
                { upiId, creditCard },
                { headers: { "Authorization": `Bearer ${token}` } }
            );
            alert("Payment methods updated!");
        } catch (error) {
            console.error("Error updating payment methods:", error);
            alert("Failed to update payment methods. Please try again.");
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleLogout = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("isLoggedIn"); // Clear login status if stored
        navigate("/login");
    };

    // Define styles object
    const styles = {
        body: {
            fontFamily: "Arial, sans-serif",
            margin: 0,
            padding: 0,
            backgroundColor: "#f5f5f5",
        },
        header: {
            backgroundColor: "#e63946",
            color: "white",
            textAlign: "center",
            padding: "20px",
            fontSize: "1.5rem",
            fontWeight: "bold",
        },
        container: {
            maxWidth: "900px",
            margin: "20px auto",
            padding: "20px",
            backgroundColor: "#fff",
            borderRadius: "10px",
            boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
        },
        section: {
            marginBottom: "20px",
        },
        sectionHeader: {
            fontSize: "1.2rem",
            fontWeight: "bold",
            marginBottom: "10px",
            color: "#333",
        },
        infoList: {
            listStyle: "none",
            padding: 0,
            margin: 0,
        },
        infoItem: {
            marginBottom: "10px",
            fontSize: "1rem",
            color: "#555",
        },
        button: {
            backgroundColor: "#e63946",
            color: "#fff",
            padding: "10px 20px",
            border: "none",
            borderRadius: "5px",
            fontSize: "1rem",
            fontWeight: "bold",
            cursor: "pointer",
            display: "block",
            marginTop: "10px",
        },
        footer: {
            display: "flex",
            justifyContent: "space-around",
            backgroundColor: "#e63946",
            padding: "15px",
            position: "fixed",
            bottom: 0,
            width: "100%",
        },
        footerButton: {
            background: "none",
            border: "none",
            color: "white",
            fontSize: "1.2rem",
            cursor: "pointer",
            fontWeight: "bold",
        },
        form: {
            display: "flex",
            flexDirection: "column",
            gap: "10px",
        },
        input: {
            padding: "10px",
            fontSize: "1rem",
            borderRadius: "5px",
            border: "1px solid #ccc",
        },
        button1: {
            backgroundColor: "#e63946",
            color: "white",
            padding: "10px 20px",
            border: "none",
            borderRadius: "5px",
            fontSize: "1rem",
            fontWeight: "bold",
            cursor: "pointer",
            marginTop: "20px",
        },
    };

    return (
        <div style={styles.body}>
            <header style={styles.header}>
                <h1>MY PROFILE</h1>
            </header>

            <div style={styles.container}>
                {/* User Info */}
                <section style={styles.section}>
                    <h2 style={styles.sectionHeader}>User Information</h2>
                    {!isEditing ? (
                        <ul style={styles.infoList}>
                            <li style={styles.infoItem}>Name: {name || "Not Set"}</li>
                            <li style={styles.infoItem}>Email: {email || "Not Set"}</li>
                            <li style={styles.infoItem}>Phone: {phone || "Not Set"}</li>
                        </ul>
                    ) : (
                        <form style={styles.form} onSubmit={handleProfileSubmit}>
                            <input
                                type="text"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                placeholder="Enter name"
                                style={styles.input}
                            />
                            <input
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                placeholder="Enter email"
                                style={styles.input}
                            />
                            <input
                                type="tel"
                                value={phone}
                                onChange={(e) => setPhone(e.target.value)}
                                placeholder="Enter phone number"
                                style={styles.input}
                            />
                            <button type="submit" style={styles.button} disabled={isSubmitting}>
                                {isSubmitting ? "Saving..." : "Save Profile"}
                            </button>
                        </form>
                    )}
                    <button
                        style={styles.button}
                        onClick={() => setIsEditing((prev) => !prev)}
                    >
                        {isEditing ? "Cancel" : "Edit Profile"}
                    </button>
                </section>

                {/* Payment Methods */}
                <section style={styles.section}>
                    <h2 style={styles.sectionHeader}>Saved Payment Methods</h2>
                    {!isManagingPayment ? (
                        <ul style={styles.infoList}>
                            <li style={styles.infoItem}>UPI ID: {upiId || "Not Set"}</li>
                            <li style={styles.infoItem}>Credit Card: {creditCard || "Not Set"}</li>
                        </ul>
                    ) : (
                        <form style={styles.form} onSubmit={handlePaymentSubmit}>
                            <input
                                type="text"
                                value={upiId}
                                onChange={(e) => setUpiId(e.target.value)}
                                placeholder="Enter UPI ID"
                                style={styles.input}
                            />
                            <input
                                type="text"
                                value={creditCard}
                                onChange={(e) => setCreditCard(e.target.value)}
                                placeholder="Enter Credit Card Number"
                                style={styles.input}
                            />
                            <button type="submit" style={styles.button} disabled={isSubmitting}>
                                {isSubmitting ? "Saving..." : "Save Payment Methods"}
                            </button>
                        </form>
                    )}
                    <button
                        style={styles.button}
                        onClick={() => setIsManagingPayment((prev) => !prev)}
                    >
                        {isManagingPayment ? "Cancel" : "Manage Payment Methods"}
                    </button>
                    <button onClick={handleLogout} style={styles.button1}>
                        Logout
                    </button>
                </section>
            </div>
        </div>
    );
}

export default ProfilePage;
