import React from "react";
import { useNavigate } from "react-router-dom";

function MainPage() {
    const navigate = useNavigate(); // Hook for navigation

    // Check if JWT token exists in localStorage for authentication
    const isLoggedIn = localStorage.getItem("token");

    const styles = {
        body: {
            fontFamily: "Arial, sans-serif",
            margin: 0,
            padding: 0,
        },
        header: {
            backgroundColor: "#000",
            color: "white",
            textAlign: "center",
            padding: "40px",
            fontSize: "1.5rem",
        },
        nav: {
            backgroundColor: "#e63946",
            display: "flex",
            justifyContent: "center",
            padding: "15px",
            fontSize: "1.2rem",
        },
        navLink: {
            color: "white",
            margin: "0 25px",
            textDecoration: "none",
            fontWeight: "bold",
            fontSize: "1.1rem",
        },
        movieSection: {
            textAlign: "center",
            padding: "40px",
            fontSize: "1.3rem",
        },
        movieList: {
            display: "flex",
            justifyContent: "center",
            gap: "40px",
            flexWrap: "wrap",
        },
        movieImage: {
            width: "150px",
            height: "auto",
            cursor: "pointer",
            transition: "transform 0.3s",
            borderRadius: "8px",
        },
        footer: {
            display: "flex",
            justifyContent: "space-around",
            backgroundColor: "#e63946",
            padding: "15px",
        },
        footerButton: {
            background: "none",
            border: "none",
            color: "white",
            fontSize: "1.2rem",
            cursor: "pointer",
            fontWeight: "bold",
        },
    };

    const goToMovie = (moviePage) => {
        if (!isLoggedIn) {
            navigate("/LoginPage"); // Redirect to login if not logged in
        } else {
            navigate(moviePage); // Otherwise, go to movie page
        }
    };

    // Movie navigation logic
    const goToProfile = () => {
        if (!isLoggedIn) {
            navigate("/login"); // Redirect to login if not logged in
        } else {
            navigate("/profile"); // Otherwise, go to profile page
        }
    };

    return (
        <div style={styles.body}>
            <header style={styles.header}>
                <h1>IT ALL BEGINS HERE!</h1>
                <nav style={styles.nav}>
                    <a href="#" style={styles.navLink}>NEWEST MOVIES</a>
                    <a href="#" style={styles.navLink}>TICKET LIBRARY</a>
                    <a href="#" style={styles.navLink}>COMEDY SHOWS</a>
                    <a href="#" style={styles.navLink}>SEE ALL</a>
                </nav>
            </header>

            {/* Movie Section */}
            <section style={styles.movieSection}>
                <h2>Current Running Movies</h2>
                <div style={styles.movieList}>
                    <img
                        src="https://images.filmibeat.com/img/popcorn/movie_posters/aavesham-20240312101525-22446.jpg"
                        alt="Aavesham"
                        style={styles.movieImage}
                        onClick={() => goToMovie("/aavesham")}
                    />
                    <img
                        src="https://streamcoimg-a.akamaihd.net/000/390/610/390610-Banner-L2-0e59ff7ab9f97b360adde8be8b46be51.jpeg"
                        alt="A Beautiful Mind"
                        style={styles.movieImage}
                        onClick={() => goToMovie("/beautiful-mind")}
                    />
                    <img
                        src="https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/95/3d/91/953d911d-04ad-1c58-c10d-9ce3068377ad/cover.jpg/1200x1200bf-60.jpg"
                        alt="Krishnam Pranaya Sakhi"
                        style={styles.movieImage}
                        onClick={() => goToMovie("/krishnam")}
                    />
                    <img
                        src="https://th.bing.com/th/id/OIP.O6Dfm9HMcFl4f3fVfsnG_AAAAA?rs=1&pid=ImgDetMain"
                        alt="Devara"
                        style={styles.movieImage}
                        onClick={() => goToMovie("/devara")}
                    />
                    <img
                        src="https://th.bing.com/th/id/OIP.nPD-HC9trgx5jCL88aqa4gAAAA?rs=1&pid=ImgDetMain"
                        alt="Pathaan"
                        style={styles.movieImage}
                        onClick={() => goToMovie("/pathaan")}
                    />
                </div>
            </section>

            {/* Footer */}
            <footer style={styles.footer}>
                <button style={styles.footerButton} onClick={() => alert("View Movies!")}>MOVIES</button>
                <button style={styles.footerButton} onClick={() => alert("View Location!")}>LOCATION</button>
                <button style={styles.footerButton} onClick={() => alert("View Tickets!")}>TICKETS</button>
                <button style={styles.footerButton} onClick={goToProfile}>PROFILE</button>
            </footer>
        </div>
    );
}

export default MainPage;
