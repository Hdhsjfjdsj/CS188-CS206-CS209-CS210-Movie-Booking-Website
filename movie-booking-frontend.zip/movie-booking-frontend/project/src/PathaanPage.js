import React from "react";
import { useNavigate } from "react-router-dom";

function Pathaan() {
    const navigate = useNavigate(); // Hook to navigate

    // Function to navigate to the booking page
    const handleBookTicketsClick = () => {
        navigate("/booking"); // This will navigate to the booking route
    };
    const styles = {
        body: {
            fontFamily:
                "'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif",
            backgroundColor: "#fff",
            margin: 0,
            padding: 0,
            color: "#333",
            textAlign: "center",
        },
        container: {
            maxWidth: "1080px",
            margin: "auto",
            padding: "20px",
        },
        title: {
            fontSize: "4rem",
            fontWeight: "bold",
        },
        movieInfo: {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-around",
            marginTop: "20px",
        },
        movieImageWrapper: {
            position: "relative",
            maxWidth: "50%",
        },
        movieImage: {
            width: "100%",
            borderRadius: "8px",
        },
        trailerButton: {
            position: "absolute",
            top: "20px",
            left: "20px",
            background: "rgba(255, 0, 0, 0.8)",
            color: "white",
            fontWeight: "bold",
            padding: "10px",
            borderRadius: "5px",
            cursor: "pointer",
        },
        description: {
            maxWidth: "45%",
            textAlign: "left",
        },
        descriptionText: {
            fontSize: "1.2rem",
            fontWeight: "normal",
            marginTop: 0,
        },
        stats: {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-around",
            marginTop: "10px",
        },
        rating: {
            fontSize: "1.5rem",
            color: "#000",
        },
        options: {
            display: "flex",
            justifyContent: "center",
            gap: "20px",
            marginTop: "20px",
        },
        option: {
            backgroundColor: "#000",
            color: "#fff",
            padding: "10px 10px",
            borderRadius: "6px",
        },
        ticketsInfo: {
            fontSize: "1.5rem",
            color: "green",
            marginTop: "10px",
        },
        bookButton: {
            backgroundColor: "red",
            color: "white",
            width: "100%",
            display: "block",
            textDecoration: "none",
            textAlign: "center",
            padding: "10px 20px",
            fontSize: "1rem",
            fontWeight: "bold",
            textTransform: "uppercase",
            borderRadius: "5px",
            marginTop: "20px",
        },
    };

    return (
        <div style={styles.body}>
            <div style={styles.container}>
                {/* Title */}
                <div style={styles.title}>PATHAAN</div>

                {/* Movie Info Section */}
                <div style={styles.movieInfo}>
                    {/* Movie Image */}
                    <div style={styles.movieImageWrapper}>
                        <a href="https://www.example.com/book-tickets">
                            <img
                                src="https://lehren.com/wp-content/uploads/2022/12/Shah-Rukh-Khan-Pathaan-Release-Date-1024x576.jpg"
                                alt="PATHAAN Movie Poster"
                                style={styles.movieImage}
                            />
                        </a>
                        <div style={styles.trailerButton}>&gt; TRAILER (4)</div>
                    </div>

                    {/* Description */}
                    <div style={styles.description}>
                        <p style={styles.descriptionText}>
                            Pathaan, a RAW agent, and his senior officer Nandini Grewal, form
                            a unit known as "Joint Operations and Covert Research" (J.O.C.R.)
                            to recruit ex-agents and soldiers who were forced to retire, but
                            want to continue serving their country. With Colonel Sunil
                            Luthra's permission, Pathaan and his team head to Dubai to stop
                            Outfit X's suspected plans of attacking the President of India.
                            However, they realise that their actual plan was to kidnap two
                            scientists, Dr. Farooqui and Dr. Sahani....more
                        </p>
                        <div style={styles.stats}>
                            <div style={styles.rating}>⭐ 8.7/10 (372.2K Views)</div>
                            <div style={styles.options}>
                                <div style={styles.option}>2D IMAX 2D, 4DX, ICE</div>
                                <div style={styles.option}>HINDI, TELUGU, +3</div>
                            </div>
                        </div>
                        <div style={styles.ticketsInfo}>
                            10.11K Tickets booked in last 24 hours
                        </div>
                    </div>
                </div>

                {/* Book Button */}
                <a  style={styles.bookButton} onClick={handleBookTicketsClick}>
                    Book Tickets
                </a>
            </div>
        </div>
    );
}

export default Pathaan;