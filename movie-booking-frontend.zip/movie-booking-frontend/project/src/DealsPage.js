import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const DealsPage = () => {
  const [isDealTaken, setIsDealTaken] = useState(null);
  const [isSkipVisible, setIsSkipVisible] = useState(true); // Track visibility of the skip button
  const navigate = useNavigate();

  const handleSkipClick = () => {
    navigate("/confirm"); // Navigate to confirmation page
  };

  const handleDealButtonClick = (dealId) => {
    setIsDealTaken(dealId); // Track which deal was taken
    setIsSkipVisible(false); // Hide skip button after deal is taken

    // Set a timeout to redirect to the confirmation page after a delay
    setTimeout(() => {
      navigate("/confirm");
    }, 500);
  };

  const styles = {
    "*": {
      margin: 0,
      padding: 0,
      boxSizing: "border-box",
      fontFamily: "Arial, sans-serif",
    },
    body: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      minHeight: "100vh",
      backgroundColor: "#f8f8f8",
    },
    dealsContainer: {
      width: "80%",
      maxWidth: "1000px",
      backgroundColor: "#fff",
      padding: "20px",
      borderRadius: "12px",
      boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
      textAlign: "center",
    },
    h1: {
      fontSize: "2rem",
      color: "purple",
      marginBottom: "30px",
    },
    deal: {
      display: "flex",
      alignItems: "center",
      borderBottom: "1px solid #ddd",
      padding: "20px 0",
    },
    dealLast: {
      borderBottom: "none",
    },
    dealImage: {
      width: "100px",
      height: "100px",
      borderRadius: "10px",
      marginRight: "20px",
    },
    dealInfo: {
      flex: 1,
      textAlign: "left",
    },
    dealHeader: {
      display: "flex",
      alignItems: "center",
      marginBottom: "5px",
    },
    dealLogo: {
      width: "30px",
      height: "auto",
      marginRight: "10px",
    },
    dealTitle: {
      fontWeight: "bold",
      fontSize: "1.1rem",
      marginRight: "10px",
    },
    dealVerified: {
      color: "green",
      fontSize: "0.9rem",
    },
    dealInfoP: {
      fontSize: "0.9rem",
      color: "#555",
      margin: "5px 0",
    },
    dealLink: {
      color: "#1a73e8",
      fontSize: "0.9rem",
      textDecoration: "none",
    },
    dealLinkHover: {
      textDecoration: "underline",
    },
    dealButton: {
      backgroundColor: "#1a73e8",
      color: "#fff",
      padding: "10px 15px",
      fontSize: "0.9rem",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
    },
    dealButtonHover: {
      backgroundColor: "#155a9b",
    },
    skipButton: {
      position: "fixed",
      bottom: "20px",
      right: "20px",
      backgroundColor: "#ff6347",
      color: "#fff",
      padding: "10px 20px",
      fontSize: "0.9rem",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
      display: isSkipVisible ? "block" : "none", // Conditional rendering
    },
    skipButtonHover: {
      backgroundColor: "#d9534f",
    },
    dealTakenButton: {
      backgroundColor: "green",
      color: "white",
      padding: "10px 20px",
      marginTop: "10px",
      border: "none",
      cursor: "pointer",
    },
  };

  return (
    <div style={styles.dealsContainer}>
      <h1 style={styles.h1}>Exciting Deals on Movie Tickets!!</h1>

      <div style={styles.deal}>
        <img
          src="popcorn_image.jpeg"
          alt="Popcorn"
          style={styles.dealImage}
        />
        <div style={styles.dealInfo}>
          <div style={styles.dealHeader}>
            <span style={styles.dealTitle}>BUY 1 GET 1 FREE</span>
            <span style={styles.dealVerified}>✔ Verified</span>
          </div>
          <p style={styles.dealInfoP}>
            Buy 1 Get 1 Free On All Movie Tickets | Bank Offers
          </p>
        </div>
        <button
          style={styles.dealButton}
          onClick={() => handleDealButtonClick(1)}
        >
          SHOW COUPON CODE
        </button>
        {isDealTaken === 1 && (
          <button style={styles.dealTakenButton}>Deal Taken!</button>
        )}
      </div>

      <div style={styles.deal}>
        <img src="pvr_logo.png" alt="PVR Logo" style={styles.dealImage} />
        <div style={styles.dealInfo}>
          <div style={styles.dealHeader}>
            <span style={styles.dealTitle}>BLOCKBUSTER</span>
            <span style={styles.dealVerified}>✔ Verified</span>
          </div>
          <p style={styles.dealInfoP}>
            Earn Up To 25% Cashback On Booking Tickets For Devara Part 1 Movie
          </p>
        </div>
        <button
          style={styles.dealButton}
          onClick={() => handleDealButtonClick(2)}
        >
          GET DEAL
        </button>
        {isDealTaken === 2 && (
          <button style={styles.dealTakenButton}>Deal Taken!</button>
        )}
      </div>

      {/* Skip button */}
      <button
        style={styles.skipButton}
        onClick={handleSkipClick}
      >
        Skip
      </button>
    </div>
  );
};

export default DealsPage;
