import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./confirm.css"; // Ensure you have the appropriate CSS for styling

const ConfirmPayment = () => {
  const [selectedPayment, setSelectedPayment] = useState("");
  const navigate = useNavigate();

  const handlePaymentChange = (e) => {
    setSelectedPayment(e.target.value);
  };

  const redirectToTicket = () => {
    if (selectedPayment) {
      // If payment option is selected, redirect to ticket page
      navigate("/ticket");
    } else {
      // Alert if no payment method is selected
      alert("Please select a payment method.");
    }
  };

  return (
    <div className="payment-container">
      <h1>CONFIRM PAYMENT</h1>
      <div className="content">
        <div className="movie-info">
          <img
            src="download.jpeg"
            alt="Devara Movie Poster"
            className="movie-poster"
          />
          <p className="movie-details">INOX GALLERIA | TELUGU | 2D</p>
          <p className="seats">E4, E5, E6</p>
        </div>
        <div className="payment-info">
          <h2>
            TOTAL AMOUNT PAYABLE: <span>600 Rs</span>
          </h2>
          <p>Payment Preference:</p>
          <div className="payment-options">
            <label>
              <input
                type="radio"
                name="payment"
                value="upi"
                onChange={handlePaymentChange}
              />
              <img src="upi_icon.png" alt="UPI Icon" /> UPI
            </label>
            <label>
              <input
                type="radio"
                name="payment"
                value="credit-card"
                onChange={handlePaymentChange}
              />
              <img
                src="credit_card.jpeg"
                alt="Credit Card Icon"
              />{" "}
              CREDIT CARD
            </label>
            <label>
              <input
                type="radio"
                name="payment"
                value="net-banking"
                onChange={handlePaymentChange}
              />
              <img src="net_banking.png" alt="Net Banking Icon" /> NET BANKING
            </label>
          </div>

          <button className="confirm-button" onClick={redirectToTicket}>
            CONFIRM
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmPayment;
