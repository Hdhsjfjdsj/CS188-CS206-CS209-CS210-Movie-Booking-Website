import React from "react";
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from "react-router-dom";
import MainPage from "./MainPage"; // Replace with the actual file name for the home page component
import DevaraPage from "./DevaraPage"; // Replace with the actual file name for the Devara page component
import BeautifulMindPage from "./BeautifulMindPage";
import PathaanPage from"./PathaanPage";
import KrishnamPranayaSakhiPage from"./KrishnamPranayaSakhiPage";
import AaveshamPage from"./AaveshamPage";
import BookingPage from "./BookingPage";
import FoodMenuPage from "./FoodMenuPage";
import BookingConfirmationPage from "./BookingConfirmationPage";
import DealsPage from "./DealsPage";
import ConfirmPage from "./ConfirmPage"
import TicketPage from "./TicketPage"
import ProfilePage from "./ProfilePage"
import LoginPage from "./LoginPage"
import RegisterUserPage from "./register"; 




function App() {
    const styles = {
        nav: {
            backgroundColor: "#e63946",
            padding: "10px",
            display: "flex",
            justifyContent: "center",
        },
        navLink: {
            color: "white",
            textDecoration: "none",
            fontWeight: "bold",
            fontSize: "1.2rem",
            margin: "0 20px",
            cursor: "pointer",
        },
    };

    const Home = () => {
        const navigate = useNavigate(); // Hook to navigate programmatically

        const styles = {
            movieImage: {
                width: "150px",
                height: "auto",
                cursor: "pointer",
                transition: "transform 0.3s",
                borderRadius: "8px",
            },
            movieList: {
                display: "flex",
                justifyContent: "center",
                gap: "20px",
                flexWrap: "wrap",
                padding: "20px",
            },
        };

        return (
            <div>
                <h1 style={{ textAlign: "center" }}>Welcome to the Movie App</h1>
                <div style={styles.movieList}>
                    <img
                        src="https://images.filmibeat.com/img/popcorn/movie_posters/aavesham-20240312101525-22446.jpg"
                        alt="Aavesham"
                        style={styles.movieImage}
                        onClick={() => navigate("/aavesham")}
                    />
                    {/* Devara movie image with click handler */}
                    <img
                        src="https://th.bing.com/th/id/OIP.O6Dfm9HMcFl4f3fVfsnG_AAAAA?rs=1&pid=ImgDetMain"
                        alt="Devara"
                        style={styles.movieImage}
                        onClick={() => navigate("/devara")} // Navigate to DevaraPage
                    />
                    {/* A Beautiful Mind movie image with click handler */}
                    <img
                        src="https://streamcoimg-a.akamaihd.net/000/390/610/390610-Banner-L2-0e59ff7ab9f97b360adde8be8b46be51.jpeg"
                        alt="A Beautiful Mind"
                        style={styles.movieImage}
                        onClick={() => navigate("/beautiful mind")}
                    />
                    {/*pathaan click handler*/}
                    <img
                        src="https://th.bing.com/th/id/OIP.nPD-HC9trgx5jCL88aqa4gAAAA?rs=1&pid=ImgDetMain"
                        alt="Pathaan"
                        style={styles.movieImage}
                        onClick={() => navigate("/pathaan")}
                    />
                    <img
                        src="https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/95/3d/91/953d911d-04ad-1c58-c10d-9ce3068377ad/cover.jpg/1200x1200bf-60.jpg"
                        alt="Krishnam Pranaya Sakhi"
                        style={styles.movieImage}
                        onClick={() => navigate("/krishnam")}
                    />
                </div>
            </div>
        );
    };

    return (
        <Router>
            <div>
                
                
                {/* Define Routes */}
                <Routes>
                    <Route path="/" element={<MainPage />} />
                    <Route path="/aavesham" element={<AaveshamPage/>}/>
                    <Route path="/devara" element={<DevaraPage />} />
                    <Route path="/beautiful mind" element={<BeautifulMindPage />} />
                    <Route path="/pathaan" element={<PathaanPage />} />
                    <Route path="/krishnam" element={<KrishnamPranayaSakhiPage />} />
                    <Route path="/booking" element={<BookingPage />} />
                    <Route path="/food-menu" element={<FoodMenuPage />} />
                    <Route path="/booking-confirmation" element={<BookingConfirmationPage />}/>
                    <Route path="/deals" element={<DealsPage />} />
                    <Route path="/confirm" element={<ConfirmPage />} />
                    <Route path="/ticket" element={<TicketPage />} />
                    <Route path="/profile" element={<ProfilePage />} />
                    <Route path="/login" element={<LoginPage />} />
                    <Route path="/register" element={<RegisterUserPage />}/>
                    
                </Routes>
            </div>
        </Router>
    );
}

export default App;
