import React, { useState } from "react";
import axios from "axios"; // To make HTTP requests
import { useNavigate } from "react-router-dom";

function RegisterUserPage() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const [successMessage, setSuccessMessage] = useState(""); // Success message state
    const [isSubmitting, setIsSubmitting] = useState(false); // For disabling button
    const navigate = useNavigate();

    // Handle registration form submission
    const handleRegister = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        setError(""); // Clear previous errors
        setSuccessMessage(""); // Clear previous success message

        const userData = {
            name,
            email,
            password,
        };

        try {
            // Send data to your backend API
            const response = await axios.post("http://localhost:5000/api/auth/register", userData);

            // If registration is successful, show a success message
            setSuccessMessage("Registration successful! You can now log in.");
            setName(""); // Clear the form fields
            setEmail("");
            setPassword("");
            
            // Redirect to login page after a delay
            setTimeout(() => {
                navigate("/login"); // Redirect to login page
            }, 2000); // 2 seconds delay to show success message
        } catch (error) {
            // Handle any errors (e.g., username already taken)
            if (error.response) {
                setError(error.response.data.message || "Registration failed. Please try again.");
            } else {
                setError("Registration failed. Please try again.");
            }
        } finally {
            setIsSubmitting(false); // Enable the button again
        }
    };

    return (
        <div style={styles.body}>
            <header style={styles.header}>
                <h1>Create a New Account</h1>
            </header>

            <div style={styles.container}>
                <form onSubmit={handleRegister} style={styles.form}>
                    <div style={styles.inputGroup}>
                        <label htmlFor="name" style={styles.label}>Name:</label>
                        <input
                            type="text"
                            id="name"
                            placeholder="Enter your name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            style={styles.input}
                            required
                        />
                    </div>
                    <div style={styles.inputGroup}>
                        <label htmlFor="email" style={styles.label}>Email:</label>
                        <input
                            type="email"
                            id="email"
                            placeholder="Enter your email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            style={styles.input}
                            required
                        />
                    </div>
                    <div style={styles.inputGroup}>
                        <label htmlFor="password" style={styles.label}>Password:</label>
                        <input
                            type="password"
                            id="password"
                            placeholder="Enter your password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            style={styles.input}
                            required
                        />
                    </div>
                    {error && <p style={styles.errorMessage}>{error}</p>}
                    {successMessage && <p style={styles.successMessage}>{successMessage}</p>} {/* Display success message */}
                    <button type="submit" style={styles.button} disabled={isSubmitting}>
                        {isSubmitting ? "Registering..." : "Register"}
                    </button>
                </form>
                <div style={styles.loginLinkContainer}>
                    <p style={styles.loginText}>Already have an account?{" "}
                        <span onClick={() => navigate("/login")} style={styles.loginLink}>
                            Login here
                        </span>
                    </p>
                </div>
            </div>
        </div>
    );
}

const styles = {
    body: {
        fontFamily: "Arial, sans-serif",
        margin: 0,
        padding: 0,
        backgroundColor: "#f5f5f5",
    },
    header: {
        backgroundColor: "#e63946",
        color: "white",
        textAlign: "center",
        padding: "20px",
        fontSize: "1.5rem",
        fontWeight: "bold",
    },
    container: {
        maxWidth: "400px",
        margin: "40px auto",
        padding: "20px",
        backgroundColor: "#fff",
        borderRadius: "10px",
        boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
    },
    form: {
        display: "flex",
        flexDirection: "column",
        gap: "15px",
    },
    inputGroup: {
        display: "flex",
        flexDirection: "column",
    },
    label: {
        fontSize: "1rem",
        marginBottom: "5px",
        fontWeight: "bold",
        color: "#333",
    },
    input: {
        padding: "10px",
        fontSize: "1rem",
        borderRadius: "5px",
        border: "1px solid #ddd",
        marginBottom: "10px",
    },
    button: {
        backgroundColor: "#e63946",
        color: "white",
        padding: "10px 20px",
        border: "none",
        borderRadius: "5px",
        fontSize: "1rem",
        fontWeight: "bold",
        cursor: "pointer",
        transition: "background-color 0.3s",
    },
    buttonHover: {
        backgroundColor: "#d62828",
    },
    errorMessage: {
        color: "red",
        fontSize: "0.9rem",
        marginBottom: "10px",
    },
    successMessage: {
        color: "green",
        fontSize: "1rem",
        marginBottom: "10px",
    },
    loginLinkContainer: {
        marginTop: "20px",
        textAlign: "center",
    },
    loginText: {
        fontSize: "1rem",
    },
    loginLink: {
        color: "#e63946",
        fontWeight: "bold",
        cursor: "pointer",
    },
};

export default RegisterUserPage;
